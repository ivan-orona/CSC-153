﻿/**
* February 8, 2017
* CSC 153
* Miguel Orona
* This program will recieve the user's input of how many miles have been driven
* and how many gallons of gas were used. After processing the input, the
* program will output the mpg that the car used.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2T1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles;
            double gallons;
            double mpg;

            miles = double.Parse(milesTextBox.Text);
            gallons = double.Parse(gallonsTextBox.Text);
            mpg = miles / gallons;
            mpgLabel.Text = mpg.ToString();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
//End program