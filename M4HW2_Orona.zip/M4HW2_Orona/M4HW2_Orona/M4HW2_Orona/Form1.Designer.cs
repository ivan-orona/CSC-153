﻿namespace M4HW2_Orona
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.oneDie = new System.Windows.Forms.PictureBox();
            this.fourDie = new System.Windows.Forms.PictureBox();
            this.sixDie = new System.Windows.Forms.PictureBox();
            this.twoDie = new System.Windows.Forms.PictureBox();
            this.fiveDie = new System.Windows.Forms.PictureBox();
            this.threeDie = new System.Windows.Forms.PictureBox();
            this.rollButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.oneDie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fourDie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixDie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoDie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiveDie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeDie)).BeginInit();
            this.SuspendLayout();
            // 
            // oneDie
            // 
            this.oneDie.Image = ((System.Drawing.Image)(resources.GetObject("oneDie.Image")));
            this.oneDie.Location = new System.Drawing.Point(84, 73);
            this.oneDie.Name = "oneDie";
            this.oneDie.Size = new System.Drawing.Size(104, 103);
            this.oneDie.TabIndex = 4;
            this.oneDie.TabStop = false;
            // 
            // fourDie
            // 
            this.fourDie.Image = ((System.Drawing.Image)(resources.GetObject("fourDie.Image")));
            this.fourDie.Location = new System.Drawing.Point(258, 222);
            this.fourDie.Name = "fourDie";
            this.fourDie.Size = new System.Drawing.Size(106, 104);
            this.fourDie.TabIndex = 5;
            this.fourDie.TabStop = false;
            // 
            // sixDie
            // 
            this.sixDie.Image = ((System.Drawing.Image)(resources.GetObject("sixDie.Image")));
            this.sixDie.Location = new System.Drawing.Point(433, 222);
            this.sixDie.Name = "sixDie";
            this.sixDie.Size = new System.Drawing.Size(106, 104);
            this.sixDie.TabIndex = 6;
            this.sixDie.TabStop = false;
            // 
            // twoDie
            // 
            this.twoDie.Image = ((System.Drawing.Image)(resources.GetObject("twoDie.Image")));
            this.twoDie.Location = new System.Drawing.Point(84, 222);
            this.twoDie.Name = "twoDie";
            this.twoDie.Size = new System.Drawing.Size(104, 104);
            this.twoDie.TabIndex = 7;
            this.twoDie.TabStop = false;
            // 
            // fiveDie
            // 
            this.fiveDie.Image = ((System.Drawing.Image)(resources.GetObject("fiveDie.Image")));
            this.fiveDie.Location = new System.Drawing.Point(433, 73);
            this.fiveDie.Name = "fiveDie";
            this.fiveDie.Size = new System.Drawing.Size(106, 103);
            this.fiveDie.TabIndex = 8;
            this.fiveDie.TabStop = false;
            // 
            // threeDie
            // 
            this.threeDie.Image = ((System.Drawing.Image)(resources.GetObject("threeDie.Image")));
            this.threeDie.Location = new System.Drawing.Point(258, 72);
            this.threeDie.Name = "threeDie";
            this.threeDie.Size = new System.Drawing.Size(106, 104);
            this.threeDie.TabIndex = 9;
            this.threeDie.TabStop = false;
            // 
            // rollButton
            // 
            this.rollButton.Location = new System.Drawing.Point(182, 373);
            this.rollButton.Name = "rollButton";
            this.rollButton.Size = new System.Drawing.Size(95, 43);
            this.rollButton.TabIndex = 10;
            this.rollButton.Text = "Roll!";
            this.rollButton.UseVisualStyleBackColor = true;
            this.rollButton.Click += new System.EventHandler(this.rollButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(330, 373);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(111, 43);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 459);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.rollButton);
            this.Controls.Add(this.threeDie);
            this.Controls.Add(this.fiveDie);
            this.Controls.Add(this.twoDie);
            this.Controls.Add(this.sixDie);
            this.Controls.Add(this.fourDie);
            this.Controls.Add(this.oneDie);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.oneDie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fourDie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixDie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoDie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiveDie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeDie)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox oneDie;
        private System.Windows.Forms.PictureBox fourDie;
        private System.Windows.Forms.PictureBox sixDie;
        private System.Windows.Forms.PictureBox twoDie;
        private System.Windows.Forms.PictureBox fiveDie;
        private System.Windows.Forms.PictureBox threeDie;
        private System.Windows.Forms.Button rollButton;
        private System.Windows.Forms.Button exitButton;
    }
}

