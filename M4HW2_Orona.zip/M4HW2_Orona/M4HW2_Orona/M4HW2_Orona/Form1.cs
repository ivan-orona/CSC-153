﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW2_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            int showDie;

            Random rand = new Random();

            showDie = rand.Next(5);

                if (showDie == 0)
                {
                    oneDie.Visible = true;
                    twoDie.Visible = false;
                    threeDie.Visible = false;
                    fourDie.Visible = true;
                    fiveDie.Visible = false;
                    sixDie.Visible = false;
                }
                if (showDie == 1)
                {
                    oneDie.Visible = false;
                    twoDie.Visible = true;
                    threeDie.Visible = false;
                    fourDie.Visible = false;
                    fiveDie.Visible = true;
                    sixDie.Visible = false;
                }
                if (showDie == 2)
                {
                    oneDie.Visible = false;
                    twoDie.Visible = false;
                    threeDie.Visible = true;
                    fourDie.Visible = false;
                    fiveDie.Visible = true;
                    sixDie.Visible = false;
                }
                if (showDie == 3)
                {
                    oneDie.Visible = false;
                    twoDie.Visible = false;
                    threeDie.Visible = false;
                    fourDie.Visible = true;
                    fiveDie.Visible = false;
                    sixDie.Visible = true;
                }
                if (showDie == 4)
                {
                    oneDie.Visible = true;
                    twoDie.Visible = false;
                    threeDie.Visible = false;
                    fourDie.Visible = false;
                    fiveDie.Visible = true;
                    sixDie.Visible = false;
                }
                if (showDie == 5)
                {
                    oneDie.Visible = false;
                    twoDie.Visible = true;
                    threeDie.Visible = false;
                    fourDie.Visible = false;
                    fiveDie.Visible = false;
                    sixDie.Visible = true;
                }
            }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
