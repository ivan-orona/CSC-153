﻿/**
* April 18, 2018
* CSC 153
* Miguel Ivan Orona
* This program will prompt the user to enter the time
* in seconds an object has fallen and the program
* will output the distance the object has traveled. 
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            DisplayDistance();
            InitializeComponent();
        }
        private void DisplayDistance()
        {
            double time;
            double gravity;
            double finalDistance;

            time = inputBox;
            gravity = 9.8;
            finalDistance = (((0.5 * gravity)*(time * time))); 

        }


        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
