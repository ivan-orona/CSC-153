﻿/**
* May 3, 2018
* CSC 153
* Miguel Ivan Orona
* This program will allow the user to input a dollar amount to either be 
* withdrawn or deposited, displaying the amount within the bank account.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_Simulator
{
    public partial class Form1 : Form
    {
        //BankAccount field with $1000 starting balance.
        private BankAccount account = new BankAccount(1000);

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Display the starting balance.
            balanceLabel.Text = account.Balance.ToString("c");
        }

        private void depositButton_Click(object sender, EventArgs e)
        {
            decimal amount; //To hold the amount deposited.

            //Convert the amount to a decimal
            if(decimal.TryParse(depositTextBox.Text, out amount))
            {
                //deposit the amount into the account
                account.Deposit(amount);

                //display the new balance.
                balanceLabel.Text = account.Balance.ToString("c");

                //Clear the text box.
                depositTextBox.Clear();
            }
            else
            {
                //Display an error message.
                MessageBox.Show("invalid amount");
            }
        }



        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the form.
            this.Close();
        }

        private void withdrawButton_Click(object sender, EventArgs e)
        {
            decimal amount; //To hold the amount withdrawn

            //Convert the amount to a decimal
            if (decimal.TryParse(withdrawTextBox.Text, out amount))
            {
                //withdraw the amount from the account.
                account.withdraw(amount);

                //Display the new balance
                balanceLabel.Text = account.Balance.ToString("c");

                //Clear the  box.
                withdrawTextBox.Clear();
            }
            else
            {
                //Display an error message.
                MessageBox.Show("Invalid amount");
            }
        }
    }
}
//End program