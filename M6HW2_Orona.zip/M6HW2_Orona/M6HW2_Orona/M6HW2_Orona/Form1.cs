﻿/**
* April 18, 2018
* CSC 153
* Miguel Ivan Orona
* This program will prompt the user to enter and check information
* boxes and process the input. After the input is processed 
* the program will output a breakdown of costs.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW2_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
