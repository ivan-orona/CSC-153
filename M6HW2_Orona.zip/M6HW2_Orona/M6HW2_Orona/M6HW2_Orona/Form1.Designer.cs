﻿namespace M6HW2_Orona
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupOilBox1 = new System.Windows.Forms.GroupBox();
            this.groupFlushBox2 = new System.Windows.Forms.GroupBox();
            this.groupMiscBox3 = new System.Windows.Forms.GroupBox();
            this.groupPartsBox4 = new System.Windows.Forms.GroupBox();
            this.groupSummaryBox5 = new System.Windows.Forms.GroupBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.OilChangeCheckBox1 = new System.Windows.Forms.CheckBox();
            this.LubeCheckBox2 = new System.Windows.Forms.CheckBox();
            this.radiatorFlushCheckBox3 = new System.Windows.Forms.CheckBox();
            this.transmissionFlushCheckBox4 = new System.Windows.Forms.CheckBox();
            this.inspectionCheckBox5 = new System.Windows.Forms.CheckBox();
            this.replaceMufflerCheckBox6 = new System.Windows.Forms.CheckBox();
            this.tireRotationcheckBox7 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.laborTextBox1 = new System.Windows.Forms.TextBox();
            this.partsTextBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.totalFeeOutputBox = new System.Windows.Forms.TextBox();
            this.taxOutputBox = new System.Windows.Forms.TextBox();
            this.partsOutputBox = new System.Windows.Forms.TextBox();
            this.serviceAndLaborOutputBox = new System.Windows.Forms.TextBox();
            this.groupOilBox1.SuspendLayout();
            this.groupFlushBox2.SuspendLayout();
            this.groupMiscBox3.SuspendLayout();
            this.groupPartsBox4.SuspendLayout();
            this.groupSummaryBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupOilBox1
            // 
            this.groupOilBox1.Controls.Add(this.OilChangeCheckBox1);
            this.groupOilBox1.Controls.Add(this.LubeCheckBox2);
            this.groupOilBox1.Location = new System.Drawing.Point(9, 44);
            this.groupOilBox1.Name = "groupOilBox1";
            this.groupOilBox1.Size = new System.Drawing.Size(148, 100);
            this.groupOilBox1.TabIndex = 0;
            this.groupOilBox1.TabStop = false;
            this.groupOilBox1.Text = "Oil and Lube";
            // 
            // groupFlushBox2
            // 
            this.groupFlushBox2.Controls.Add(this.radiatorFlushCheckBox3);
            this.groupFlushBox2.Controls.Add(this.transmissionFlushCheckBox4);
            this.groupFlushBox2.Location = new System.Drawing.Point(180, 44);
            this.groupFlushBox2.Name = "groupFlushBox2";
            this.groupFlushBox2.Size = new System.Drawing.Size(158, 100);
            this.groupFlushBox2.TabIndex = 0;
            this.groupFlushBox2.TabStop = false;
            this.groupFlushBox2.Text = "Flushes";
            // 
            // groupMiscBox3
            // 
            this.groupMiscBox3.Controls.Add(this.inspectionCheckBox5);
            this.groupMiscBox3.Controls.Add(this.replaceMufflerCheckBox6);
            this.groupMiscBox3.Controls.Add(this.tireRotationcheckBox7);
            this.groupMiscBox3.Location = new System.Drawing.Point(9, 150);
            this.groupMiscBox3.Name = "groupMiscBox3";
            this.groupMiscBox3.Size = new System.Drawing.Size(148, 100);
            this.groupMiscBox3.TabIndex = 0;
            this.groupMiscBox3.TabStop = false;
            this.groupMiscBox3.Text = "Misc";
            // 
            // groupPartsBox4
            // 
            this.groupPartsBox4.Controls.Add(this.label1);
            this.groupPartsBox4.Controls.Add(this.label2);
            this.groupPartsBox4.Controls.Add(this.laborTextBox1);
            this.groupPartsBox4.Controls.Add(this.partsTextBox2);
            this.groupPartsBox4.Location = new System.Drawing.Point(180, 150);
            this.groupPartsBox4.Name = "groupPartsBox4";
            this.groupPartsBox4.Size = new System.Drawing.Size(158, 100);
            this.groupPartsBox4.TabIndex = 0;
            this.groupPartsBox4.TabStop = false;
            this.groupPartsBox4.Text = "Parts and Labor";
            // 
            // groupSummaryBox5
            // 
            this.groupSummaryBox5.Controls.Add(this.serviceAndLaborOutputBox);
            this.groupSummaryBox5.Controls.Add(this.partsOutputBox);
            this.groupSummaryBox5.Controls.Add(this.taxOutputBox);
            this.groupSummaryBox5.Controls.Add(this.totalFeeOutputBox);
            this.groupSummaryBox5.Controls.Add(this.label6);
            this.groupSummaryBox5.Controls.Add(this.label5);
            this.groupSummaryBox5.Controls.Add(this.label4);
            this.groupSummaryBox5.Controls.Add(this.label3);
            this.groupSummaryBox5.Location = new System.Drawing.Point(9, 256);
            this.groupSummaryBox5.Name = "groupSummaryBox5";
            this.groupSummaryBox5.Size = new System.Drawing.Size(329, 127);
            this.groupSummaryBox5.TabIndex = 0;
            this.groupSummaryBox5.TabStop = false;
            this.groupSummaryBox5.Text = "Summary";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(30, 399);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 0;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(132, 399);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(230, 399);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // OilChangeCheckBox1
            // 
            this.OilChangeCheckBox1.AutoSize = true;
            this.OilChangeCheckBox1.Location = new System.Drawing.Point(7, 30);
            this.OilChangeCheckBox1.Name = "OilChangeCheckBox1";
            this.OilChangeCheckBox1.Size = new System.Drawing.Size(120, 17);
            this.OilChangeCheckBox1.TabIndex = 3;
            this.OilChangeCheckBox1.Text = "Oil Change ($26.00)";
            this.OilChangeCheckBox1.UseVisualStyleBackColor = true;
            // 
            // LubeCheckBox2
            // 
            this.LubeCheckBox2.AutoSize = true;
            this.LubeCheckBox2.Location = new System.Drawing.Point(6, 63);
            this.LubeCheckBox2.Name = "LubeCheckBox2";
            this.LubeCheckBox2.Size = new System.Drawing.Size(112, 17);
            this.LubeCheckBox2.TabIndex = 4;
            this.LubeCheckBox2.Text = "Lube Job ($18.00)";
            this.LubeCheckBox2.UseVisualStyleBackColor = true;
            // 
            // radiatorFlushCheckBox3
            // 
            this.radiatorFlushCheckBox3.AutoSize = true;
            this.radiatorFlushCheckBox3.Location = new System.Drawing.Point(6, 30);
            this.radiatorFlushCheckBox3.Name = "radiatorFlushCheckBox3";
            this.radiatorFlushCheckBox3.Size = new System.Drawing.Size(136, 17);
            this.radiatorFlushCheckBox3.TabIndex = 5;
            this.radiatorFlushCheckBox3.Text = "Radiator Flush ($30.00)";
            this.radiatorFlushCheckBox3.UseVisualStyleBackColor = true;
            // 
            // transmissionFlushCheckBox4
            // 
            this.transmissionFlushCheckBox4.AutoSize = true;
            this.transmissionFlushCheckBox4.Location = new System.Drawing.Point(6, 63);
            this.transmissionFlushCheckBox4.Name = "transmissionFlushCheckBox4";
            this.transmissionFlushCheckBox4.Size = new System.Drawing.Size(157, 17);
            this.transmissionFlushCheckBox4.TabIndex = 6;
            this.transmissionFlushCheckBox4.Text = "Transmission Flush ($80.00)";
            this.transmissionFlushCheckBox4.UseVisualStyleBackColor = true;
            // 
            // inspectionCheckBox5
            // 
            this.inspectionCheckBox5.AutoSize = true;
            this.inspectionCheckBox5.Location = new System.Drawing.Point(7, 19);
            this.inspectionCheckBox5.Name = "inspectionCheckBox5";
            this.inspectionCheckBox5.Size = new System.Drawing.Size(117, 17);
            this.inspectionCheckBox5.TabIndex = 7;
            this.inspectionCheckBox5.Text = "Inspection ($15.00)";
            this.inspectionCheckBox5.UseVisualStyleBackColor = true;
            // 
            // replaceMufflerCheckBox6
            // 
            this.replaceMufflerCheckBox6.AutoSize = true;
            this.replaceMufflerCheckBox6.Location = new System.Drawing.Point(6, 42);
            this.replaceMufflerCheckBox6.Name = "replaceMufflerCheckBox6";
            this.replaceMufflerCheckBox6.Size = new System.Drawing.Size(149, 17);
            this.replaceMufflerCheckBox6.TabIndex = 8;
            this.replaceMufflerCheckBox6.Text = "Replace Muffler ($100.00)";
            this.replaceMufflerCheckBox6.UseVisualStyleBackColor = true;
            // 
            // tireRotationcheckBox7
            // 
            this.tireRotationcheckBox7.AutoSize = true;
            this.tireRotationcheckBox7.Location = new System.Drawing.Point(6, 65);
            this.tireRotationcheckBox7.Name = "tireRotationcheckBox7";
            this.tireRotationcheckBox7.Size = new System.Drawing.Size(129, 17);
            this.tireRotationcheckBox7.TabIndex = 9;
            this.tireRotationcheckBox7.Text = "Tire Rotation ($20.00)";
            this.tireRotationcheckBox7.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Parts";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Labor ($)";
            // 
            // laborTextBox1
            // 
            this.laborTextBox1.Location = new System.Drawing.Point(62, 55);
            this.laborTextBox1.Name = "laborTextBox1";
            this.laborTextBox1.Size = new System.Drawing.Size(88, 20);
            this.laborTextBox1.TabIndex = 5;
            // 
            // partsTextBox2
            // 
            this.partsTextBox2.Location = new System.Drawing.Point(62, 29);
            this.partsTextBox2.Name = "partsTextBox2";
            this.partsTextBox2.Size = new System.Drawing.Size(88, 20);
            this.partsTextBox2.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Service and Labor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(104, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Parts:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(61, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Tax (on parts):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(76, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Total Fees:";
            // 
            // totalFeeOutputBox
            // 
            this.totalFeeOutputBox.Location = new System.Drawing.Point(160, 92);
            this.totalFeeOutputBox.Name = "totalFeeOutputBox";
            this.totalFeeOutputBox.Size = new System.Drawing.Size(100, 20);
            this.totalFeeOutputBox.TabIndex = 4;
            // 
            // taxOutputBox
            // 
            this.taxOutputBox.Location = new System.Drawing.Point(160, 66);
            this.taxOutputBox.Name = "taxOutputBox";
            this.taxOutputBox.Size = new System.Drawing.Size(100, 20);
            this.taxOutputBox.TabIndex = 5;
            // 
            // partsOutputBox
            // 
            this.partsOutputBox.Location = new System.Drawing.Point(160, 40);
            this.partsOutputBox.Name = "partsOutputBox";
            this.partsOutputBox.Size = new System.Drawing.Size(100, 20);
            this.partsOutputBox.TabIndex = 6;
            // 
            // serviceAndLaborOutputBox
            // 
            this.serviceAndLaborOutputBox.Location = new System.Drawing.Point(160, 13);
            this.serviceAndLaborOutputBox.Name = "serviceAndLaborOutputBox";
            this.serviceAndLaborOutputBox.Size = new System.Drawing.Size(100, 20);
            this.serviceAndLaborOutputBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 445);
            this.Controls.Add(this.groupFlushBox2);
            this.Controls.Add(this.groupMiscBox3);
            this.Controls.Add(this.groupPartsBox4);
            this.Controls.Add(this.groupSummaryBox5);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.groupOilBox1);
            this.Name = "Form1";
            this.Text = "Automotive";
            this.groupOilBox1.ResumeLayout(false);
            this.groupOilBox1.PerformLayout();
            this.groupFlushBox2.ResumeLayout(false);
            this.groupFlushBox2.PerformLayout();
            this.groupMiscBox3.ResumeLayout(false);
            this.groupMiscBox3.PerformLayout();
            this.groupPartsBox4.ResumeLayout(false);
            this.groupPartsBox4.PerformLayout();
            this.groupSummaryBox5.ResumeLayout(false);
            this.groupSummaryBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupOilBox1;
        private System.Windows.Forms.CheckBox OilChangeCheckBox1;
        private System.Windows.Forms.CheckBox LubeCheckBox2;
        private System.Windows.Forms.GroupBox groupFlushBox2;
        private System.Windows.Forms.CheckBox radiatorFlushCheckBox3;
        private System.Windows.Forms.CheckBox transmissionFlushCheckBox4;
        private System.Windows.Forms.GroupBox groupMiscBox3;
        private System.Windows.Forms.CheckBox inspectionCheckBox5;
        private System.Windows.Forms.CheckBox replaceMufflerCheckBox6;
        private System.Windows.Forms.CheckBox tireRotationcheckBox7;
        private System.Windows.Forms.GroupBox groupPartsBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox laborTextBox1;
        private System.Windows.Forms.TextBox partsTextBox2;
        private System.Windows.Forms.GroupBox groupSummaryBox5;
        private System.Windows.Forms.TextBox serviceAndLaborOutputBox;
        private System.Windows.Forms.TextBox partsOutputBox;
        private System.Windows.Forms.TextBox taxOutputBox;
        private System.Windows.Forms.TextBox totalFeeOutputBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

