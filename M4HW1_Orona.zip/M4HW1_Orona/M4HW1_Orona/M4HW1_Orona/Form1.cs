﻿
/**
* March 14, 2018
* CSC 153
* Miguel Ivan Orona
* This program will display a table of predicted data of organisms multiplied
* throughout a set period of time.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int organismBox;
            int dailyBox;
            int multiplyBox;
            int organism;
            int daily;
            int multiply;

            //Math equation for expected increase.
            organism = organismBox;
            daily = dailyBox;
            multiply = multiplyBox;



        }
    }
}
