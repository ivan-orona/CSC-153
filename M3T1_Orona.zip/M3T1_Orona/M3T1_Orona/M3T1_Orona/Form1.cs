﻿/**
* February 19, 2018
* CSC 153
* Miguel Ivan Orona
* This program will prompt the user to enter their hourly pay combined with the hours
* worked and output the gross pay with/without overtime pay depending 
* on how many hours were worked.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3T1_Orona
{
    public partial class payrollOvertime : Form
    {
        public payrollOvertime()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //constants are named.
                const decimal BASE_HOURS = 40m;
                const decimal OT_MULTIPLIER = 1.5m;

                //local variables.
                decimal hoursWorked;
                decimal hourlyPayRate;
                decimal basePay;
                decimal overtimeHours;
                decimal overtimePay;
                decimal grossPay;

                //hours worked and hourly pay.
                hoursWorked = decimal.Parse(hoursWorkedTextBox.Text);
                hourlyPayRate = decimal.Parse(hourlyPayRateTextBox.Text);

                //determining the gross pay.
                if (hoursWorked > BASE_HOURS)
                {
                    //The normal base pay is calculated.
                    basePay = hourlyPayRate * BASE_HOURS;

                    //Ovetime hours are calculated using the base hours.
                    overtimeHours = hoursWorked - BASE_HOURS;

                    //Overtime pay is calculated.
                    overtimePay = overtimeHours * hourlyPayRate * OT_MULTIPLIER;

                    //The final gross pay is calculated.
                    grossPay = basePay + overtimePay;
                }
                else
                {
                    //Grosspay is calulated.
                    grossPay = hoursWorked * hourlyPayRate;
                }
                //The grosspay is displayed.
                grossPayLabel.Text = grossPay.ToString("c");
            }
            catch(Exception ex)
            {
                //The error message is displayed.
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            hoursWorkedTextBox.Text = "";
            hourlyPayRateTextBox.Text = "";
            grossPayLabel.Text = "";

            hoursWorkedTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //This button closes the application.
            this.Close();
        }
    }
}
