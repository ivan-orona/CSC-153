﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Orona
{
    public partial class romanNumeralConverter : Form
    {
        public romanNumeralConverter()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;
            int number;

            if (int.TryParse(input, out number))
            {
                switch (number)
                {
                    case 1:
                        outputTextBox.Text = ("I");
                        break;
                    case 2:
                        outputTextBox.Text = ("II");
                        break;
                    case 3:
                        outputTextBox.Text = ("III");
                        break;
                    case 4:
                        outputTextBox.Text = ("IV");
                        break;
                    case 5:
                        outputTextBox.Text = ("V");
                        break;
                    case 6:
                        outputTextBox.Text = ("VI");
                        break;
                    case 7:
                        outputTextBox.Text = ("VII");
                        break;
                    case 8:
                        outputTextBox.Text = ("VIII");
                        break;
                    case 9:
                        outputTextBox.Text = ("IX");
                        break;
                    case 10:
                        outputTextBox.Text = ("X");
                        break;
                }
            }
            else
            {
                outputTextBox.Text ("That is not a valid integer!");
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
//End of program