﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH9PP4_Orona
{
    public class employee
    {
        string _name;   //holds name
        string _department; //holds department
        string _position;   //holds position
        decimal _idNum; //holds ID

        public employee()
        {
            _name = "";
            _department = "";
            _position = "";
            _idNum = 0;

        }
        public employee(string name, decimal idNum, string department, string position)
        {
            _name = name;
            _department = department;
            _position = position;
            _idNum = idNum;
        }

        public employee (string name, decimal idNum)
        {
            _name = name;
            _idNum = idNum;
            _department = "";
            _position = "";
        }

        public string Name
        {
            //returns name info
            set { _name = value; }
            get { return _name; }
        }
        public string Department
        {
            //returns department info
            set { _department = value; }
            get { return _department; }
        }
        public string Position
        {   
            //Returns position info
            set { _position = value; }
            get { return _position; }
        }
        public decimal idNum
        {
            //Returns id info
            set { _idNum = value; }
            get { return _idNum; }
        }
    }
}
