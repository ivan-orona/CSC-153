﻿/**
* May 16, 2018
* CSC 153
* Miguel Ivan Orona
* This program will retrieve stored information when 
* prompted and output the information.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CH9PP4_Orona
{
    public partial class Form1 : Form
    {
        //Employee class is assigned to three employees.
        private employee employee1 = new employee("Susan Meyers", 47899, "Accounting", "Vice President");
        private employee employee2 = new employee("Mark Jones", 39119, "IT", "Programmer");
        private employee employee3 = new employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            //Displays the first employees information
            firstEmployeeBox.Text = employee1.Name + " " + employee1.idNum + " " +
          employee1.Department + " " + employee1.Position;

            //Second employee Information 
            secondEmployeeBox.Text = employee2.Name + " " + employee2.idNum + " " +
                employee2.Department + " " + employee2.Position;

            //Third employee information
            thirdEmployeeBox.Text = employee3.Name + " " + employee3.idNum + " " +
              employee1.Department + " " + employee3.Position;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the form.
            this.Close();
        }
    }
}
//End program.