﻿/**
* May 15, 2018
* CSC 153
* Miguel Ivan Orona
* This program will output stored information when prompted an display the information.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //The class for friends. Also specifies that there is 3.
        private friend[] addedFriends = new friend[3];


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Assigns my information using the addedFriends class.
            addedFriends[0] = new friend();
            addedFriends[0].Name = "Ivan Orona";
            addedFriends[0].Address = "Fayetteville, NC";
            addedFriends[0].Age = 24;
            addedFriends[0].Phone = "555.555.5555";

            //Assigns my information using the addedFriends class.
            addedFriends[1] = new friend();
            addedFriends[1].Name = "Tia Orona";
            addedFriends[1].Address = "Fayetteville, NC";
            addedFriends[1].Age = 23;
            addedFriends[1].Phone = "555.555.5555";

            //Assigns my brother's information using the addedFriends Class.
            addedFriends[2] = new friend();
            addedFriends[2].Name = "Venni Orona";
            addedFriends[2].Address = "Bay Point, NC";
            addedFriends[2].Age = 27;
            addedFriends[2].Phone = "555.555.5555";


        }

        private void showButton_Click(object sender, EventArgs e)
        {
            //Display my personal information.
            myTextBox.Text = addedFriends[0].Name + " " +
            addedFriends[0].Address + " " + addedFriends[0].Age +
            " " + addedFriends[0].Phone;

            //Display's my wife's information.
            wifeTextBox.Text = addedFriends[1].Name + " " +
            addedFriends[1].Address + " " + addedFriends[1].Age +
            " " + addedFriends[1].Phone;

            //Display's my brother's information.
            brotherTextBox.Text = addedFriends[2].Name + " " +
            addedFriends[2].Address + " " + addedFriends[2].Age +
            " " + addedFriends[2].Phone;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exits the program.
            this.Close();
        }
    }
}
//End program.