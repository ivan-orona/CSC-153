﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class friend
    {
        //Fields
        string _name;
        string _address;
        double _age;
        string _phone;

        //Constructor.
        public String Name
        {
            set { _name = value; }
            get { return _name; }
        }

        public String Address
        {
            set { _address = value; }
            get { return _address; }
        }

        public double Age
        {
            set { _age = value; }
            get { return _age; }
        }
        
        public string Phone
        {
            set { _phone = value; }
            get { return _phone; }
        }
    }
}
