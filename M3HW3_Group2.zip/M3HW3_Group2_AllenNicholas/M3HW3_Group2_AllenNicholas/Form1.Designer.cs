﻿namespace M3HW3_Group2_AllenNicholas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.workshopListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.locationListBox = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.registrationCost = new System.Windows.Forms.Label();
            this.registrationCostLabel = new System.Windows.Forms.Label();
            this.lodgingCost = new System.Windows.Forms.Label();
            this.lodgingCostLabel = new System.Windows.Forms.Label();
            this.totalCost = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numberOfDayLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select a Workshop:";
            // 
            // workshopListBox
            // 
            this.workshopListBox.FormattingEnabled = true;
            this.workshopListBox.Items.AddRange(new object[] {
            "Handling Stress",
            "Time Management",
            "Supervision Skills",
            "Negotiation",
            "How to Interview"});
            this.workshopListBox.Location = new System.Drawing.Point(15, 27);
            this.workshopListBox.Name = "workshopListBox";
            this.workshopListBox.Size = new System.Drawing.Size(120, 95);
            this.workshopListBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(169, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select a Location:";
            // 
            // locationListBox
            // 
            this.locationListBox.FormattingEnabled = true;
            this.locationListBox.Items.AddRange(new object[] {
            "Austin",
            "Chicago",
            "Dallas",
            "Orlando",
            "Phoenix",
            "Raleigh"});
            this.locationListBox.Location = new System.Drawing.Point(172, 27);
            this.locationListBox.Name = "locationListBox";
            this.locationListBox.Size = new System.Drawing.Size(120, 95);
            this.locationListBox.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(109, 138);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Calculate Costs";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // registrationCost
            // 
            this.registrationCost.AutoSize = true;
            this.registrationCost.Location = new System.Drawing.Point(12, 175);
            this.registrationCost.Name = "registrationCost";
            this.registrationCost.Size = new System.Drawing.Size(90, 13);
            this.registrationCost.TabIndex = 5;
            this.registrationCost.Text = "Registration Cost:";
            // 
            // registrationCostLabel
            // 
            this.registrationCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.registrationCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registrationCostLabel.Location = new System.Drawing.Point(109, 170);
            this.registrationCostLabel.Name = "registrationCostLabel";
            this.registrationCostLabel.Size = new System.Drawing.Size(182, 23);
            this.registrationCostLabel.TabIndex = 6;
            this.registrationCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lodgingCost
            // 
            this.lodgingCost.AutoSize = true;
            this.lodgingCost.Location = new System.Drawing.Point(14, 213);
            this.lodgingCost.Name = "lodgingCost";
            this.lodgingCost.Size = new System.Drawing.Size(72, 13);
            this.lodgingCost.TabIndex = 7;
            this.lodgingCost.Text = "Lodging Cost:";
            // 
            // lodgingCostLabel
            // 
            this.lodgingCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lodgingCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lodgingCostLabel.Location = new System.Drawing.Point(110, 208);
            this.lodgingCostLabel.Name = "lodgingCostLabel";
            this.lodgingCostLabel.Size = new System.Drawing.Size(182, 23);
            this.lodgingCostLabel.TabIndex = 8;
            this.lodgingCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalCost
            // 
            this.totalCost.AutoSize = true;
            this.totalCost.Location = new System.Drawing.Point(13, 289);
            this.totalCost.Name = "totalCost";
            this.totalCost.Size = new System.Drawing.Size(58, 13);
            this.totalCost.TabIndex = 9;
            this.totalCost.Text = "Total Cost:";
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCostLabel.Location = new System.Drawing.Point(110, 284);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(182, 23);
            this.totalCostLabel.TabIndex = 10;
            this.totalCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Number of Days:";
            // 
            // numberOfDayLabel
            // 
            this.numberOfDayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberOfDayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberOfDayLabel.Location = new System.Drawing.Point(110, 244);
            this.numberOfDayLabel.Name = "numberOfDayLabel";
            this.numberOfDayLabel.Size = new System.Drawing.Size(181, 23);
            this.numberOfDayLabel.TabIndex = 12;
            this.numberOfDayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 319);
            this.Controls.Add(this.numberOfDayLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.totalCost);
            this.Controls.Add(this.lodgingCostLabel);
            this.Controls.Add(this.lodgingCost);
            this.Controls.Add(this.registrationCostLabel);
            this.Controls.Add(this.registrationCost);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.locationListBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.workshopListBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Workshop Selector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox workshopListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox locationListBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label registrationCost;
        private System.Windows.Forms.Label registrationCostLabel;
        private System.Windows.Forms.Label lodgingCost;
        private System.Windows.Forms.Label lodgingCostLabel;
        private System.Windows.Forms.Label totalCost;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label numberOfDayLabel;
    }
}

