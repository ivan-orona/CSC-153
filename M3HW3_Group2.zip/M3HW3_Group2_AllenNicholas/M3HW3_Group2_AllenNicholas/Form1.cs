﻿/**
* 02/26/2018
* CSC 153
* Nicholas Allen - Coded the program
* Rashad Henry   - Wrote the pseudo code
* Miguel Orona   - Created the flowchart
* Calculates total cost based on workshop and location selected
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW3_Group2_AllenNicholas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double days = 0;            // Initalize number of days
            double lodgingCost = 0;     // Initalize lodging cost
            double registration = 0;    // Initalize registration cost

            /* 
             * Gets the workshop and displays registration costs and number of days
             */
            switch (workshopListBox.SelectedIndex)
            {
                case 0:
                    registration = 1000;
                    registrationCostLabel.Text = "$" + registration.ToString();
                    days = 3;
                    numberOfDayLabel.Text = days.ToString();
                    break;
                case 1:
                    registration = 800;
                    registrationCostLabel.Text = "$" + registration.ToString();
                    days = 3;
                    numberOfDayLabel.Text = days.ToString();
                    break;
                case 2:
                    registration = 1500;
                    registrationCostLabel.Text = "$" + registration.ToString();
                    days = 3;
                    numberOfDayLabel.Text = days.ToString();
                    break;
                case 3:
                    registration = 1300;
                    registrationCostLabel.Text = "$" + registration.ToString();
                    days = 5;
                    numberOfDayLabel.Text = days.ToString();
                    break;
                case 4:
                    registration = 500;
                    registrationCostLabel.Text = "$" + registration.ToString();
                    days = 1;
                    numberOfDayLabel.Text = days.ToString();
                    break;

            }

            /*
             * Gets the selected location and displays the lodging costs
             */
            switch (locationListBox.SelectedIndex)
            {
                case 0:
                    lodgingCost = 150 * days;
                    lodgingCostLabel.Text = "$" + lodgingCost.ToString();
                    break;
                case 1:
                    lodgingCost = 225 * days;
                    lodgingCostLabel.Text = "$" + lodgingCost.ToString();
                    break;
                case 2:
                    lodgingCost = 175 * days;
                    lodgingCostLabel.Text = "$" + lodgingCost.ToString();
                    break;
                case 3:
                    lodgingCost = 300 * days;
                    lodgingCostLabel.Text = "$" + lodgingCost.ToString();
                    break;
                case 4:
                    lodgingCost = 175 * days;
                    lodgingCostLabel.Text = "$" + lodgingCost.ToString();
                    break;
                case 5:
                    lodgingCost = 150 * days;
                    lodgingCostLabel.Text = "$" + lodgingCost.ToString();
                    break;
            }

            double totalCost = registration + lodgingCost;      // Calculates total cost for registration and lodging
            totalCostLabel.Text = "$" + totalCost.ToString();   // Displays the Total cost
        }
    }
}
