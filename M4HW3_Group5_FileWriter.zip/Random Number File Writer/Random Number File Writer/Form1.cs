﻿/**
* 04/08/2018
* CSC 153
* Group 5: Miguel Orona, Cameron Scott, Aaron Williams
* This program will write random numbers to a file.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Random_Number_File_Writer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void randomNumberButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Variables
                int amountOfRandomNumbers;
                int randomNumber;
                Random rand = new Random();

                // Creates a streamwriter object
                StreamWriter outputFile;

                //outputFile = File.CreateText("RNG.txt");
                if (int.TryParse(randomNumberTextBox.Text, out amountOfRandomNumbers))
                {
                    if (saveFile.ShowDialog() == DialogResult.OK)
                    {
                        // Lets the user save a file
                        outputFile = File.CreateText(saveFile.FileName);
                        saveFile.InitialDirectory = "C:\\Data";
                        // For loop that will run it reaches the amount specified by the user
                        for (int randomNumberCounter = 1; randomNumberCounter <= amountOfRandomNumbers; randomNumberCounter++)
                        {
                            // Creates a random number object
                            randomNumber = rand.Next(100);
                            // Generates a random number to write to the file
                            outputFile.WriteLine(randomNumber);
                        }
                        // Closes the file
                        outputFile.Close();
                        MessageBox.Show("Random numbers generated.");
                    }
                    else
                    {
                        // Message is displayed if the user cancels the saving operation
                        MessageBox.Show("Operation canceled.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid value entered for amount of random numbers.");
                }
            }

            catch (Exception ex)
            {
                // Displays an error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears the textbox and resets the focus to it
            randomNumberTextBox.Text = "";
            randomNumberTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exits program
            this.Close();
        }

    }
}
