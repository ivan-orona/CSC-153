﻿namespace Random_Number_File_Writer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.randomNumberTextBox = new System.Windows.Forms.TextBox();
            this.randomNumberButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Amount of Random Numbers:";
            // 
            // randomNumberTextBox
            // 
            this.randomNumberTextBox.Location = new System.Drawing.Point(164, 24);
            this.randomNumberTextBox.Name = "randomNumberTextBox";
            this.randomNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.randomNumberTextBox.TabIndex = 0;
            // 
            // randomNumberButton
            // 
            this.randomNumberButton.Location = new System.Drawing.Point(12, 65);
            this.randomNumberButton.Name = "randomNumberButton";
            this.randomNumberButton.Size = new System.Drawing.Size(75, 48);
            this.randomNumberButton.TabIndex = 1;
            this.randomNumberButton.Text = "Generate Random Numbers";
            this.randomNumberButton.UseVisualStyleBackColor = true;
            this.randomNumberButton.Click += new System.EventHandler(this.randomNumberButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(217, 65);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 48);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // saveFile
            // 
            this.saveFile.DefaultExt = "txt";
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(113, 65);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 48);
            this.clearButton.TabIndex = 2;
            this.clearButton.Text = "Clear TextBox";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(306, 138);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.randomNumberButton);
            this.Controls.Add(this.randomNumberTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Random Number Writer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox randomNumberTextBox;
        private System.Windows.Forms.Button randomNumberButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.SaveFileDialog saveFile;
        private System.Windows.Forms.Button clearButton;
    }
}

