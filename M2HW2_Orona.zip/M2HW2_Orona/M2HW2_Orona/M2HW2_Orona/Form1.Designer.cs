﻿namespace M2HW2_Orona
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.theLowerButton = new System.Windows.Forms.Button();
            this.theUpperButton = new System.Windows.Forms.Button();
            this.anLowerButton = new System.Windows.Forms.Button();
            this.anUpperButton = new System.Windows.Forms.Button();
            this.aLowerButton = new System.Windows.Forms.Button();
            this.aUpperButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.lookedAtButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.spokeToButton = new System.Windows.Forms.Button();
            this.laughedButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.exclaimButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // theLowerButton
            // 
            this.theLowerButton.Location = new System.Drawing.Point(333, 27);
            this.theLowerButton.Name = "theLowerButton";
            this.theLowerButton.Size = new System.Drawing.Size(46, 23);
            this.theLowerButton.TabIndex = 0;
            this.theLowerButton.Text = "the";
            this.theLowerButton.UseVisualStyleBackColor = true;
            this.theLowerButton.Click += new System.EventHandler(this.theLowerButton_Click);
            // 
            // theUpperButton
            // 
            this.theUpperButton.Location = new System.Drawing.Point(285, 27);
            this.theUpperButton.Name = "theUpperButton";
            this.theUpperButton.Size = new System.Drawing.Size(41, 23);
            this.theUpperButton.TabIndex = 1;
            this.theUpperButton.Text = "The";
            this.theUpperButton.UseVisualStyleBackColor = true;
            this.theUpperButton.Click += new System.EventHandler(this.theUpperButton_Click);
            // 
            // anLowerButton
            // 
            this.anLowerButton.Location = new System.Drawing.Point(240, 27);
            this.anLowerButton.Name = "anLowerButton";
            this.anLowerButton.Size = new System.Drawing.Size(35, 23);
            this.anLowerButton.TabIndex = 2;
            this.anLowerButton.Text = "an";
            this.anLowerButton.UseVisualStyleBackColor = true;
            this.anLowerButton.Click += new System.EventHandler(this.anLowerButton_Click);
            // 
            // anUpperButton
            // 
            this.anUpperButton.Location = new System.Drawing.Point(195, 27);
            this.anUpperButton.Name = "anUpperButton";
            this.anUpperButton.Size = new System.Drawing.Size(31, 23);
            this.anUpperButton.TabIndex = 3;
            this.anUpperButton.Text = "An";
            this.anUpperButton.UseVisualStyleBackColor = true;
            this.anUpperButton.Click += new System.EventHandler(this.anUpperButton_Click);
            // 
            // aLowerButton
            // 
            this.aLowerButton.Location = new System.Drawing.Point(149, 27);
            this.aLowerButton.Name = "aLowerButton";
            this.aLowerButton.Size = new System.Drawing.Size(31, 23);
            this.aLowerButton.TabIndex = 4;
            this.aLowerButton.Text = "a";
            this.aLowerButton.UseVisualStyleBackColor = true;
            this.aLowerButton.Click += new System.EventHandler(this.aLowerButton_Click);
            // 
            // aUpperButton
            // 
            this.aUpperButton.Location = new System.Drawing.Point(101, 27);
            this.aUpperButton.Name = "aUpperButton";
            this.aUpperButton.Size = new System.Drawing.Size(35, 23);
            this.aUpperButton.TabIndex = 5;
            this.aUpperButton.Text = "A";
            this.aUpperButton.UseVisualStyleBackColor = true;
            this.aUpperButton.Click += new System.EventHandler(this.aUpperButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.Location = new System.Drawing.Point(353, 56);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(75, 23);
            this.bicycleButton.TabIndex = 6;
            this.bicycleButton.Text = "bicycle ";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(311, 56);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(36, 23);
            this.carButton.TabIndex = 7;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(247, 56);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(58, 23);
            this.catButton.TabIndex = 8;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(177, 56);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(62, 23);
            this.dogButton.TabIndex = 9;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(101, 56);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(70, 23);
            this.womanButton.TabIndex = 10;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(48, 56);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(47, 23);
            this.manButton.TabIndex = 11;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(333, 85);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(75, 23);
            this.strangeButton.TabIndex = 12;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(263, 85);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(58, 23);
            this.smallButton.TabIndex = 13;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(204, 85);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(51, 23);
            this.bigButton.TabIndex = 14;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(120, 85);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(75, 23);
            this.beautifulButton.TabIndex = 15;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // lookedAtButton
            // 
            this.lookedAtButton.Location = new System.Drawing.Point(68, 114);
            this.lookedAtButton.Name = "lookedAtButton";
            this.lookedAtButton.Size = new System.Drawing.Size(75, 23);
            this.lookedAtButton.TabIndex = 16;
            this.lookedAtButton.Text = "looked at";
            this.lookedAtButton.UseVisualStyleBackColor = true;
            this.lookedAtButton.Click += new System.EventHandler(this.lookedAtButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.Location = new System.Drawing.Point(149, 114);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(46, 23);
            this.rodeButton.TabIndex = 17;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // spokeToButton
            // 
            this.spokeToButton.Location = new System.Drawing.Point(204, 114);
            this.spokeToButton.Name = "spokeToButton";
            this.spokeToButton.Size = new System.Drawing.Size(75, 23);
            this.spokeToButton.TabIndex = 18;
            this.spokeToButton.Text = "spoke to";
            this.spokeToButton.UseVisualStyleBackColor = true;
            this.spokeToButton.Click += new System.EventHandler(this.spokeToButton_Click);
            // 
            // laughedButton
            // 
            this.laughedButton.Location = new System.Drawing.Point(285, 114);
            this.laughedButton.Name = "laughedButton";
            this.laughedButton.Size = new System.Drawing.Size(75, 23);
            this.laughedButton.TabIndex = 19;
            this.laughedButton.Text = "laughed at";
            this.laughedButton.UseVisualStyleBackColor = true;
            this.laughedButton.Click += new System.EventHandler(this.laughedButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(366, 114);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(75, 23);
            this.droveButton.TabIndex = 20;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // exclaimButton
            // 
            this.exclaimButton.Location = new System.Drawing.Point(311, 172);
            this.exclaimButton.Name = "exclaimButton";
            this.exclaimButton.Size = new System.Drawing.Size(54, 23);
            this.exclaimButton.TabIndex = 21;
            this.exclaimButton.Text = "!";
            this.exclaimButton.UseVisualStyleBackColor = true;
            this.exclaimButton.Click += new System.EventHandler(this.exclaimButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(240, 172);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(39, 23);
            this.periodButton.TabIndex = 22;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(136, 172);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(75, 23);
            this.spaceButton.TabIndex = 23;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(164, 242);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 24;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(251, 242);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 25;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // outputTextBox
            // 
            this.outputTextBox.Location = new System.Drawing.Point(12, 201);
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.Size = new System.Drawing.Size(525, 20);
            this.outputTextBox.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 313);
            this.Controls.Add(this.outputTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.exclaimButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedButton);
            this.Controls.Add(this.spokeToButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.lookedAtButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.aUpperButton);
            this.Controls.Add(this.aLowerButton);
            this.Controls.Add(this.anUpperButton);
            this.Controls.Add(this.anLowerButton);
            this.Controls.Add(this.theUpperButton);
            this.Controls.Add(this.theLowerButton);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button theLowerButton;
        private System.Windows.Forms.Button theUpperButton;
        private System.Windows.Forms.Button anLowerButton;
        private System.Windows.Forms.Button anUpperButton;
        private System.Windows.Forms.Button aLowerButton;
        private System.Windows.Forms.Button aUpperButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button lookedAtButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button spokeToButton;
        private System.Windows.Forms.Button laughedButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button exclaimButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox outputTextBox;
    }
}

