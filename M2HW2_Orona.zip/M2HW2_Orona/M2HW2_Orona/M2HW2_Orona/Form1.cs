﻿/**
* 14 May 2018
* CSC 153
* Miguel Ivan Orona
* This program will prompt the user to select buttons
* that will output the processed words into a sentence.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Orona
{
    public partial class Form1 : Form
    {
        public String outputString = " ";
        public Form1()
        {
            InitializeComponent();
        }

        //The button A
        private void aUpperButton_Click(object sender, EventArgs e)
        {
            outputString = "A";
            outputTextBox.Text += outputString;
        }

        //The button a
        private void aLowerButton_Click(object sender, EventArgs e)
        {
            outputString = "a";
            outputTextBox.Text += outputString;
        }

        //The button An
        private void anUpperButton_Click(object sender, EventArgs e)
        {
            outputString = "An";
            outputTextBox.Text += outputString;
        }

        //The button an
        private void anLowerButton_Click(object sender, EventArgs e)
        {
            outputString = "an";
            outputTextBox.Text += outputString;
        }

        //The button The
        private void theUpperButton_Click(object sender, EventArgs e)
        {
            outputString = "The";
            outputTextBox.Text += outputString;
        }

        //The button the
        private void theLowerButton_Click(object sender, EventArgs e)
        {
            outputString = "the";
            outputTextBox.Text += outputString;
        }

        //The button man
        private void manButton_Click(object sender, EventArgs e)
        {
            outputString = "man";
            outputTextBox.Text += outputString;
        }

        //The button woman
        private void womanButton_Click(object sender, EventArgs e)
        {
            outputString = "woman";
            outputTextBox.Text += outputString;
        }

        //The button dog
        private void dogButton_Click(object sender, EventArgs e)
        {
            outputString = "dog";
            outputTextBox.Text += outputString;
        }

        //The button cat
        private void catButton_Click(object sender, EventArgs e)
        {
            outputString = "cat";
            outputTextBox.Text += outputString;
        }

        //The button car
        private void carButton_Click(object sender, EventArgs e)
        {
            outputString = "car";
            outputTextBox.Text += outputString;
        }

        //The button bicycle
        private void bicycleButton_Click(object sender, EventArgs e)
        {
            outputString = "bicycle";
            outputTextBox.Text += outputString;
        }

        //The button beautiful
        private void beautifulButton_Click(object sender, EventArgs e)
        {
            outputString = "beautiful";
            outputTextBox.Text += outputString;
        }

        //The button big.
        private void bigButton_Click(object sender, EventArgs e)
        {
            outputString = "big";
            outputTextBox.Text += outputString;
        }

        //The button small.
        private void smallButton_Click(object sender, EventArgs e)
        {
            outputString = "small";
            outputTextBox.Text += outputString;
        }

        //The button strange.
        private void strangeButton_Click(object sender, EventArgs e)
        { 
            outputString = "strange";
            outputTextBox.Text += outputString;
        }

        //The button looked at
        private void lookedAtButton_Click(object sender, EventArgs e)
        {
            outputString = "looked at";
            outputTextBox.Text += outputString;
        }

        //The button rode.
        private void rodeButton_Click(object sender, EventArgs e)
        {
            outputString = "rode";
            outputTextBox.Text += outputString;
        }

        //The button spoke to
        private void spokeToButton_Click(object sender, EventArgs e)
        {
            outputString = "spoke to";
            outputTextBox.Text += outputString;
        }

        //The button laughed at
        private void laughedButton_Click(object sender, EventArgs e)
        {
            outputString = "laughed at";
            outputTextBox.Text += outputString;
        }

        //The button drove
        private void droveButton_Click(object sender, EventArgs e)
        {
            outputString = "drove";
            outputTextBox.Text += outputString;

        }



        //Clear the output box.
        private void clearButton_Click(object sender, EventArgs e)
        {
            outputTextBox.Clear();
        }

        //Space button
        private void spaceButton_Click(object sender, EventArgs e)
        {
            outputString = " ";
            outputTextBox.Text += outputString;
        }

        //Period button
        private void periodButton_Click(object sender, EventArgs e)
        {
            outputString = ".";
            outputTextBox.Text += outputString;
        }

        //Exclamation mark.
        private void exclaimButton_Click(object sender, EventArgs e)
        {
            outputString = "!";
            outputTextBox.Text += outputString;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
//End program.