﻿namespace M2HW1_Orona
{
    partial class nameFormatter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.titleBox = new System.Windows.Forms.Label();
            this.firstNameBox = new System.Windows.Forms.TextBox();
            this.middleNameBox = new System.Windows.Forms.TextBox();
            this.lastNameBox = new System.Windows.Forms.TextBox();
            this.outputBox = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.styleButton1 = new System.Windows.Forms.Button();
            this.styleButton2 = new System.Windows.Forms.Button();
            this.styleButton3 = new System.Windows.Forms.Button();
            this.styleButton4 = new System.Windows.Forms.Button();
            this.styleButton5 = new System.Windows.Forms.Button();
            this.styleButton6 = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(144, 27);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(118, 13);
            this.instructionLabel.TabIndex = 0;
            this.instructionLabel.Text = "Enter the following data";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(101, 69);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstNameLabel.TabIndex = 1;
            this.firstNameLabel.Text = "First Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(100, 121);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(101, 95);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(72, 13);
            this.middleNameLabel.TabIndex = 3;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // titleBox
            // 
            this.titleBox.AutoSize = true;
            this.titleBox.Location = new System.Drawing.Point(101, 147);
            this.titleBox.Name = "titleBox";
            this.titleBox.Size = new System.Drawing.Size(76, 13);
            this.titleBox.TabIndex = 4;
            this.titleBox.Text = "Preferred Title:";
            // 
            // firstNameBox
            // 
            this.firstNameBox.Location = new System.Drawing.Point(227, 62);
            this.firstNameBox.Name = "firstNameBox";
            this.firstNameBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameBox.TabIndex = 5;
            // 
            // middleNameBox
            // 
            this.middleNameBox.Location = new System.Drawing.Point(227, 88);
            this.middleNameBox.Name = "middleNameBox";
            this.middleNameBox.Size = new System.Drawing.Size(100, 20);
            this.middleNameBox.TabIndex = 6;
            // 
            // lastNameBox
            // 
            this.lastNameBox.Location = new System.Drawing.Point(227, 114);
            this.lastNameBox.Name = "lastNameBox";
            this.lastNameBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameBox.TabIndex = 7;
            // 
            // outputBox
            // 
            this.outputBox.Location = new System.Drawing.Point(72, 321);
            this.outputBox.Name = "outputBox";
            this.outputBox.Size = new System.Drawing.Size(268, 20);
            this.outputBox.TabIndex = 8;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(227, 144);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 9;
            // 
            // styleButton1
            // 
            this.styleButton1.Location = new System.Drawing.Point(32, 216);
            this.styleButton1.Name = "styleButton1";
            this.styleButton1.Size = new System.Drawing.Size(75, 23);
            this.styleButton1.TabIndex = 10;
            this.styleButton1.Text = "Style One";
            this.styleButton1.UseVisualStyleBackColor = true;
            this.styleButton1.Click += new System.EventHandler(this.styleButton1_Click);
            // 
            // styleButton2
            // 
            this.styleButton2.Location = new System.Drawing.Point(168, 216);
            this.styleButton2.Name = "styleButton2";
            this.styleButton2.Size = new System.Drawing.Size(75, 23);
            this.styleButton2.TabIndex = 11;
            this.styleButton2.Text = "Style Two";
            this.styleButton2.UseVisualStyleBackColor = true;
            // 
            // styleButton3
            // 
            this.styleButton3.Location = new System.Drawing.Point(302, 216);
            this.styleButton3.Name = "styleButton3";
            this.styleButton3.Size = new System.Drawing.Size(75, 23);
            this.styleButton3.TabIndex = 12;
            this.styleButton3.Text = "Style 3";
            this.styleButton3.UseVisualStyleBackColor = true;
            // 
            // styleButton4
            // 
            this.styleButton4.Location = new System.Drawing.Point(32, 263);
            this.styleButton4.Name = "styleButton4";
            this.styleButton4.Size = new System.Drawing.Size(75, 23);
            this.styleButton4.TabIndex = 13;
            this.styleButton4.Text = "Style 4";
            this.styleButton4.UseVisualStyleBackColor = true;
            // 
            // styleButton5
            // 
            this.styleButton5.Location = new System.Drawing.Point(168, 263);
            this.styleButton5.Name = "styleButton5";
            this.styleButton5.Size = new System.Drawing.Size(75, 23);
            this.styleButton5.TabIndex = 14;
            this.styleButton5.Text = "Style 5";
            this.styleButton5.UseVisualStyleBackColor = true;
            // 
            // styleButton6
            // 
            this.styleButton6.Location = new System.Drawing.Point(302, 263);
            this.styleButton6.Name = "styleButton6";
            this.styleButton6.Size = new System.Drawing.Size(75, 23);
            this.styleButton6.TabIndex = 15;
            this.styleButton6.Text = "Style 6";
            this.styleButton6.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(168, 348);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 17;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // nameFormatter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 383);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.styleButton6);
            this.Controls.Add(this.styleButton5);
            this.Controls.Add(this.styleButton4);
            this.Controls.Add(this.styleButton3);
            this.Controls.Add(this.styleButton2);
            this.Controls.Add(this.styleButton1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.lastNameBox);
            this.Controls.Add(this.middleNameBox);
            this.Controls.Add(this.firstNameBox);
            this.Controls.Add(this.titleBox);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.instructionLabel);
            this.Name = "nameFormatter";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label titleBox;
        private System.Windows.Forms.TextBox firstNameBox;
        private System.Windows.Forms.TextBox middleNameBox;
        private System.Windows.Forms.TextBox lastNameBox;
        private System.Windows.Forms.TextBox outputBox;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button styleButton1;
        private System.Windows.Forms.Button styleButton2;
        private System.Windows.Forms.Button styleButton3;
        private System.Windows.Forms.Button styleButton4;
        private System.Windows.Forms.Button styleButton5;
        private System.Windows.Forms.Button styleButton6;
        private System.Windows.Forms.Button exitButton;
    }
}

