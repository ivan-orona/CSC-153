﻿/**
* February 27, 2018
* CSC 153
* Miguel Ivan Orona
* This program will prompt the user to enter a number and the program
* will translate it to a roman numeral. 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Orona
{
    public partial class romanNumeralConverter : Form
    {
        public romanNumeralConverter()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            int number;                             //Hold the number
            string input = inputTextBox.Text;       //Holds user input

            if (int.TryParse(input, out number))    //if/else statement
            {
                switch (number)
                {
                    case  1:
                        messageBox.Text = "I";
                        break;
                    case 2:
                        messageBox.Text = "II";
                        break;
                    case 3:
                        messageBox.Text = "III";
                        break;
                    case 4:
                        messageBox.Text = "IV";
                        break;
                    case 5:
                        messageBox.Text = "V";
                        break;
                    case 6:
                        messageBox.Text = "VI";
                        break;
                    case 7:
                        messageBox.Text = "VII";
                        break;
                    case 8:
                        messageBox.Text = "VIII";
                        break;
                    case 9:
                        messageBox.Text = "IX";
                        break;
                    case 10:
                        messageBox.Text = "X";
                        break;
                    default:
                        messageBox.Text = "Try a different number!"; //Prompt message if any integer over 10 is inputted.
                        break;
                }
            }
            else       //Error message if anything other than an integer is inputted.
            {
                messageBox.Text = ("Thats not an integer!");
            }

        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();               //Closes the program
        }
    }
}

//End of program