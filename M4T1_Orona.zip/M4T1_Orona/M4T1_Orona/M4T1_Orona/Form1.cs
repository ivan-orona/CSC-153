﻿/**
* March 12, 2018
* CSC 153
* Miguel Ivan Orona
* Program description
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4T1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            //Constants
            const int startSpeed = 60;
            const int endSpeed = 130;
            const int interval = 10;
            const double conversionFactor = 0.6214;

            //variables
            int kph;        //Kilometers per hour
            double mph;     //Miles per hour

            //Display the table of speeds
           for (kph = startSpeed; kph <= endSpeed; kph += interval)
            {
                //calculate miles per hour.
                mph = kph * conversionFactor;

                //Display the conversion.
                outputListBox.Items.Add(kph + "KPH is the same as " +
                    mph + " MPH");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();   //Closes the program.
        }
    }
}
//End Program.