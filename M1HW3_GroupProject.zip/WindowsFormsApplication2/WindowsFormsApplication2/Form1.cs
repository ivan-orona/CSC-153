﻿
/**
* 20180131
* CSC 153
* Michel Villafan Group 5
* Heads or Tails program
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class headsOrTails : Form
    {
        public headsOrTails()
        {
            InitializeComponent();
            //Sets both pictures unvisable at start
            pictureBoxHeads.Visible = false; 
            pictureBoxTails.Visible = false;
        }

        private void showHeadsButton_Click(object sender, EventArgs e)
        {
            //Click makes Heads Visable
            pictureBoxHeads.Visible = true;
            pictureBoxTails.Visible = false;
        }

        private void showTailsButton_Click(object sender, EventArgs e)
        {
            //Click makes Tails Visable
            pictureBoxHeads.Visible = false;
            pictureBoxTails.Visible = true;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Click exit application
            Application.Exit();
        }
    }
}
