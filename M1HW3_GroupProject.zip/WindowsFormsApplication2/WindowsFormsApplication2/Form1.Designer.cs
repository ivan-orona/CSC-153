﻿namespace WindowsFormsApplication2
{
    partial class headsOrTails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.showHeadsButton = new System.Windows.Forms.Button();
            this.showTailsButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.pictureBoxTails = new System.Windows.Forms.PictureBox();
            this.pictureBoxHeads = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHeads)).BeginInit();
            this.SuspendLayout();
            // 
            // showHeadsButton
            // 
            this.showHeadsButton.Location = new System.Drawing.Point(296, 361);
            this.showHeadsButton.Name = "showHeadsButton";
            this.showHeadsButton.Size = new System.Drawing.Size(96, 46);
            this.showHeadsButton.TabIndex = 0;
            this.showHeadsButton.Text = "Show Heads";
            this.showHeadsButton.UseVisualStyleBackColor = true;
            this.showHeadsButton.Click += new System.EventHandler(this.showHeadsButton_Click);
            // 
            // showTailsButton
            // 
            this.showTailsButton.Location = new System.Drawing.Point(296, 413);
            this.showTailsButton.Name = "showTailsButton";
            this.showTailsButton.Size = new System.Drawing.Size(96, 47);
            this.showTailsButton.TabIndex = 1;
            this.showTailsButton.Text = "Show Tails";
            this.showTailsButton.UseVisualStyleBackColor = true;
            this.showTailsButton.Click += new System.EventHandler(this.showTailsButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(296, 466);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(96, 46);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // pictureBoxTails
            // 
            this.pictureBoxTails.Image = global::WindowsFormsApplication2.Properties.Resources.tails;
            this.pictureBoxTails.Location = new System.Drawing.Point(355, 12);
            this.pictureBoxTails.Name = "pictureBoxTails";
            this.pictureBoxTails.Size = new System.Drawing.Size(327, 330);
            this.pictureBoxTails.TabIndex = 3;
            this.pictureBoxTails.TabStop = false;
            // 
            // pictureBoxHeads
            // 
            this.pictureBoxHeads.Image = global::WindowsFormsApplication2.Properties.Resources.Heads;
            this.pictureBoxHeads.Location = new System.Drawing.Point(12, 12);
            this.pictureBoxHeads.Name = "pictureBoxHeads";
            this.pictureBoxHeads.Size = new System.Drawing.Size(332, 328);
            this.pictureBoxHeads.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxHeads.TabIndex = 2;
            this.pictureBoxHeads.TabStop = false;
            // 
            // headsOrTails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 525);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.pictureBoxTails);
            this.Controls.Add(this.pictureBoxHeads);
            this.Controls.Add(this.showTailsButton);
            this.Controls.Add(this.showHeadsButton);
            this.Name = "headsOrTails";
            this.Text = "Heads or Tails";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHeads)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button showHeadsButton;
        private System.Windows.Forms.Button showTailsButton;
        private System.Windows.Forms.PictureBox pictureBoxHeads;
        private System.Windows.Forms.PictureBox pictureBoxTails;
        private System.Windows.Forms.Button exitButton;
    }
}

