﻿/**
* 04/08/2018
* CSC 153
* Group 5: Miguel Orona, Cameron Scott, Aaron Williams
* This program will read random numbers from a file and display them.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Random_Number_File_Reader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void readFileButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Variables
                int randomNumber;
                int randomNumberTotal = 0;
                int fileLinesRead = 0;
                string randomNumberString;

                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    // Creates a streamreader object
                    StreamReader inputFile;
                    // Lets the user pick a file to open
                    inputFile = File.OpenText(openFile.FileName);
                    // While loop that runs until the text document has no more lines to be read
                    while (!inputFile.EndOfStream)
                    {
                        // Reads a line from a file
                        randomNumberString = inputFile.ReadLine();
                        // Adds the read line to the listbox
                        randomNumberListBox.Items.Add(randomNumberString);
                        // Converts the read string into a integer
                        randomNumber = int.Parse(randomNumberString);
                        // Adds the integer to a total
                        randomNumberTotal += randomNumber;
                        // Counts how many lines have been read
                        fileLinesRead += 1;
                    }
                    // Closes the file being read
                    inputFile.Close();
                    // Adds the amount of lines read to the listbox
                    randomNumberListBox.Items.Add("Number of lines read:");
                    randomNumberListBox.Items.Add(fileLinesRead);
                    // Adds the total of the numbers to the listbox
                    randomNumberListBox.Items.Add("Total of the numbers in file");
                    randomNumberListBox.Items.Add(randomNumberTotal);
                }

                else
                {
                    // Displays a message if the user cancels out of opening a file
                    MessageBox.Show("Operation canceled.");
                }
            }
            catch(Exception ex)
            {
                // Displays an error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears the listbox of its contents
            randomNumberListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exits program
            this.Close();
        }
    }
}
