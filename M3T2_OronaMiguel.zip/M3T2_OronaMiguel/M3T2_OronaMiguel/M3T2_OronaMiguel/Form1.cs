﻿/**
* February 20, 2018
* CSC 153
* Miguel Ivan Orona
* This program will prompt the user to enter their mileage and
* gas information and process the input. After the input is processed
* the program will output the miles per gallon.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3T2_OronaMiguel
{
    public partial class fuelEconomy : Form
    {
        public fuelEconomy()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //holding the variables
            double miles;
            double gallons;
            double mpg;

            if(double.TryParse(milesBox.Text, out miles))
            {
                if(double.TryParse(gallonsBox.Text, out gallons))
                {
                    //calulating miles per gallon with division.
                    mpg = miles / gallons;
                    //display the mpg.
                    mpgBox.Text = mpg.ToString("n1");
                }
            }
            else
            {
                //displaying the message error for invalid inputs.
                MessageBox.Show("Invalid input for gallons.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes the program
            Close();
        }
    }
}
//End of program
