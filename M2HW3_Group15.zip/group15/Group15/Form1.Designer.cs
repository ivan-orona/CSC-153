﻿namespace Group15
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.revenueGeneratedBox = new System.Windows.Forms.GroupBox();
            this.revenueLabel = new System.Windows.Forms.Label();
            this.totalRevenueLabel = new System.Windows.Forms.Label();
            this.totalRevenueBox = new System.Windows.Forms.TextBox();
            this.revenueLabelC = new System.Windows.Forms.Label();
            this.revenueBoxA = new System.Windows.Forms.TextBox();
            this.revenueLabelB = new System.Windows.Forms.Label();
            this.revenueBoxC = new System.Windows.Forms.TextBox();
            this.revenueLabelA = new System.Windows.Forms.Label();
            this.revenueBoxB = new System.Windows.Forms.TextBox();
            this.ticketsSoldBox = new System.Windows.Forms.GroupBox();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.classLabelA = new System.Windows.Forms.Label();
            this.classBoxA = new System.Windows.Forms.TextBox();
            this.classLabelB = new System.Windows.Forms.Label();
            this.classLabelC = new System.Windows.Forms.Label();
            this.classBoxC = new System.Windows.Forms.TextBox();
            this.classBoxB = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.revenueGeneratedBox.SuspendLayout();
            this.ticketsSoldBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // revenueGeneratedBox
            // 
            this.revenueGeneratedBox.Controls.Add(this.revenueLabel);
            this.revenueGeneratedBox.Controls.Add(this.totalRevenueLabel);
            this.revenueGeneratedBox.Controls.Add(this.totalRevenueBox);
            this.revenueGeneratedBox.Controls.Add(this.revenueLabelC);
            this.revenueGeneratedBox.Controls.Add(this.revenueBoxA);
            this.revenueGeneratedBox.Controls.Add(this.revenueLabelB);
            this.revenueGeneratedBox.Controls.Add(this.revenueBoxC);
            this.revenueGeneratedBox.Controls.Add(this.revenueLabelA);
            this.revenueGeneratedBox.Controls.Add(this.revenueBoxB);
            this.revenueGeneratedBox.Location = new System.Drawing.Point(324, 13);
            this.revenueGeneratedBox.Name = "revenueGeneratedBox";
            this.revenueGeneratedBox.Size = new System.Drawing.Size(297, 274);
            this.revenueGeneratedBox.TabIndex = 25;
            this.revenueGeneratedBox.TabStop = false;
            this.revenueGeneratedBox.Text = "Revenue Generated";
            // 
            // revenueLabel
            // 
            this.revenueLabel.AutoSize = true;
            this.revenueLabel.Location = new System.Drawing.Point(28, 42);
            this.revenueLabel.Name = "revenueLabel";
            this.revenueLabel.Size = new System.Drawing.Size(104, 13);
            this.revenueLabel.TabIndex = 4;
            this.revenueLabel.Text = "Revenue Generated";
            // 
            // totalRevenueLabel
            // 
            this.totalRevenueLabel.AutoSize = true;
            this.totalRevenueLabel.Location = new System.Drawing.Point(28, 246);
            this.totalRevenueLabel.Name = "totalRevenueLabel";
            this.totalRevenueLabel.Size = new System.Drawing.Size(34, 13);
            this.totalRevenueLabel.TabIndex = 6;
            this.totalRevenueLabel.Text = "Total:";
            // 
            // totalRevenueBox
            // 
            this.totalRevenueBox.Location = new System.Drawing.Point(68, 239);
            this.totalRevenueBox.Name = "totalRevenueBox";
            this.totalRevenueBox.Size = new System.Drawing.Size(100, 20);
            this.totalRevenueBox.TabIndex = 18;
            // 
            // revenueLabelC
            // 
            this.revenueLabelC.AutoSize = true;
            this.revenueLabelC.Location = new System.Drawing.Point(17, 199);
            this.revenueLabelC.Name = "revenueLabelC";
            this.revenueLabelC.Size = new System.Drawing.Size(45, 13);
            this.revenueLabelC.TabIndex = 9;
            this.revenueLabelC.Text = "Class C:";
            // 
            // revenueBoxA
            // 
            this.revenueBoxA.Location = new System.Drawing.Point(68, 96);
            this.revenueBoxA.Name = "revenueBoxA";
            this.revenueBoxA.Size = new System.Drawing.Size(100, 20);
            this.revenueBoxA.TabIndex = 16;
            // 
            // revenueLabelB
            // 
            this.revenueLabelB.AutoSize = true;
            this.revenueLabelB.Location = new System.Drawing.Point(17, 151);
            this.revenueLabelB.Name = "revenueLabelB";
            this.revenueLabelB.Size = new System.Drawing.Size(45, 13);
            this.revenueLabelB.TabIndex = 10;
            this.revenueLabelB.Text = "Class B:";
            // 
            // revenueBoxC
            // 
            this.revenueBoxC.Location = new System.Drawing.Point(68, 192);
            this.revenueBoxC.Name = "revenueBoxC";
            this.revenueBoxC.Size = new System.Drawing.Size(100, 20);
            this.revenueBoxC.TabIndex = 15;
            // 
            // revenueLabelA
            // 
            this.revenueLabelA.AutoSize = true;
            this.revenueLabelA.Location = new System.Drawing.Point(17, 104);
            this.revenueLabelA.Name = "revenueLabelA";
            this.revenueLabelA.Size = new System.Drawing.Size(45, 13);
            this.revenueLabelA.TabIndex = 11;
            this.revenueLabelA.Text = "Class A:";
            // 
            // revenueBoxB
            // 
            this.revenueBoxB.Location = new System.Drawing.Point(68, 145);
            this.revenueBoxB.Name = "revenueBoxB";
            this.revenueBoxB.Size = new System.Drawing.Size(100, 20);
            this.revenueBoxB.TabIndex = 12;
            // 
            // ticketsSoldBox
            // 
            this.ticketsSoldBox.Controls.Add(this.instructionLabel);
            this.ticketsSoldBox.Controls.Add(this.classLabelA);
            this.ticketsSoldBox.Controls.Add(this.classBoxA);
            this.ticketsSoldBox.Controls.Add(this.classLabelB);
            this.ticketsSoldBox.Controls.Add(this.classLabelC);
            this.ticketsSoldBox.Controls.Add(this.classBoxC);
            this.ticketsSoldBox.Controls.Add(this.classBoxB);
            this.ticketsSoldBox.Location = new System.Drawing.Point(12, 12);
            this.ticketsSoldBox.Name = "ticketsSoldBox";
            this.ticketsSoldBox.Size = new System.Drawing.Size(306, 275);
            this.ticketsSoldBox.TabIndex = 24;
            this.ticketsSoldBox.TabStop = false;
            this.ticketsSoldBox.Text = "Tickets Sold";
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(17, 43);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(268, 13);
            this.instructionLabel.TabIndex = 3;
            this.instructionLabel.Text = "Enter the number of tickets sold for each class of seats.";
            // 
            // classLabelA
            // 
            this.classLabelA.AutoSize = true;
            this.classLabelA.Location = new System.Drawing.Point(75, 100);
            this.classLabelA.Name = "classLabelA";
            this.classLabelA.Size = new System.Drawing.Size(45, 13);
            this.classLabelA.TabIndex = 5;
            this.classLabelA.Text = "Class A:";
            // 
            // classBoxA
            // 
            this.classBoxA.Location = new System.Drawing.Point(137, 100);
            this.classBoxA.Name = "classBoxA";
            this.classBoxA.Size = new System.Drawing.Size(100, 20);
            this.classBoxA.TabIndex = 17;
            // 
            // classLabelB
            // 
            this.classLabelB.AutoSize = true;
            this.classLabelB.Location = new System.Drawing.Point(75, 149);
            this.classLabelB.Name = "classLabelB";
            this.classLabelB.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.classLabelB.Size = new System.Drawing.Size(45, 13);
            this.classLabelB.TabIndex = 7;
            this.classLabelB.Text = "Class B:";
            // 
            // classLabelC
            // 
            this.classLabelC.AutoSize = true;
            this.classLabelC.Location = new System.Drawing.Point(75, 200);
            this.classLabelC.Name = "classLabelC";
            this.classLabelC.Size = new System.Drawing.Size(45, 13);
            this.classLabelC.TabIndex = 8;
            this.classLabelC.Text = "Class C:";
            // 
            // classBoxC
            // 
            this.classBoxC.Location = new System.Drawing.Point(137, 193);
            this.classBoxC.Name = "classBoxC";
            this.classBoxC.Size = new System.Drawing.Size(100, 20);
            this.classBoxC.TabIndex = 13;
            // 
            // classBoxB
            // 
            this.classBoxB.Location = new System.Drawing.Point(137, 149);
            this.classBoxB.Name = "classBoxB";
            this.classBoxB.Size = new System.Drawing.Size(100, 20);
            this.classBoxB.TabIndex = 14;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(386, 305);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(90, 37);
            this.exitButton.TabIndex = 23;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(280, 305);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(80, 37);
            this.clearButton.TabIndex = 22;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(159, 305);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(90, 37);
            this.calculateButton.TabIndex = 21;
            this.calculateButton.Text = "Calculate Revenue";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 380);
            this.Controls.Add(this.revenueGeneratedBox);
            this.Controls.Add(this.ticketsSoldBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.revenueGeneratedBox.ResumeLayout(false);
            this.revenueGeneratedBox.PerformLayout();
            this.ticketsSoldBox.ResumeLayout(false);
            this.ticketsSoldBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox revenueGeneratedBox;
        private System.Windows.Forms.Label revenueLabel;
        private System.Windows.Forms.Label totalRevenueLabel;
        private System.Windows.Forms.TextBox totalRevenueBox;
        private System.Windows.Forms.Label revenueLabelC;
        private System.Windows.Forms.TextBox revenueBoxA;
        private System.Windows.Forms.Label revenueLabelB;
        private System.Windows.Forms.TextBox revenueBoxC;
        private System.Windows.Forms.Label revenueLabelA;
        private System.Windows.Forms.TextBox revenueBoxB;
        private System.Windows.Forms.GroupBox ticketsSoldBox;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label classLabelA;
        private System.Windows.Forms.TextBox classBoxA;
        private System.Windows.Forms.Label classLabelB;
        private System.Windows.Forms.Label classLabelC;
        private System.Windows.Forms.TextBox classBoxC;
        private System.Windows.Forms.TextBox classBoxB;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button calculateButton;
    }
}

