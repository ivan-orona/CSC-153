﻿/**
* Febuary 18, 2018
* CSC 153
* Matthew Hunter, Miguel Orona
* Calculate revenue based on number of tickets sold
* GUI and Flow Chart done by Miguel Orona
* Code and psudo code done by Matthew Hunter
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group15
{
    public partial class Form1 : Form
    {
        public const double CLASSACOST = 15;        //Hold constant cost of class a
        public const double CLASSBCOST = 12;        //Hold constant cost of class b
        public const double CLASSCCOST = 9;         //Hold constant cost of class c
        public double classAsold;                   //Hold input from classBoxA
        public double classBsold;                   //Hold input from classBoxB
        public double classCsold;                   //Hold input from classBoxC
        public double revenueA;                     //Hold calculation of revenue of class a tickets
        public double revenueB;                     //Hold calculation of revenue of class b tickets
        public double revenueC;                     //Hold calculation of revenue of class c tickets
        public double total;                        //Hold calculation of total revenue
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //convert and assign text in classBoxA
            classAsold = double.Parse(classBoxA.Text);

            //convert and assign text in classBoxB
            classBsold = double.Parse(classBoxB.Text);

            //convert and assign text in classBoxC
            classCsold = double.Parse(classBoxC.Text);

            //calculate and assign revenue from class a tickets
            revenueA = classAsold * CLASSACOST;

            //calculate and assign revenue from class a tickets
            revenueB = classBsold * CLASSBCOST;

            //calculate and assign revenue from class a tickets
            revenueC = classCsold * CLASSCCOST;

            //calculate and assign total revenue from all tickets
            total = revenueA + revenueB + revenueC;

            //Convert and display revenue from class a tickets
            revenueBoxA.Text = revenueA.ToString();

            //Convert and display revenue from class b tickets
            revenueBoxB.Text = revenueB.ToString();

            //Convert and display revenue from class c tickets
            revenueBoxC.Text = revenueC.ToString();

            //convert and display total revenue from all tickets
            totalRevenueBox.Text = total.ToString();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //set all input boxes to blank
            classBoxA.Text = "";

            classBoxB.Text = "";

            classBoxC.Text = "";

            revenueBoxA.Text = "";

            revenueBoxB.Text = "";

            revenueBoxC.Text = "";

            totalRevenueBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the program
            this.Close();
        }
    }
}
