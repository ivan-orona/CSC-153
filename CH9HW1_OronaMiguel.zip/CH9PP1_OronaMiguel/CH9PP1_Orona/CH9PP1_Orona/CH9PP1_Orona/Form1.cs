﻿/**
* 09 May 2018 
* CSC 153
* Miguel Ivan Orona
* This program will prompt the user to input pet
* information and the program will store the information
* in a text box after being processed. The information
* will then be available for outputted when prompted.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CH9PP1_Orona
{
    public partial class Form1 : Form
    {
        //List to hold pet objects.
        List<pet> petList = new List<pet>();

        public Form1()
        {
            InitializeComponent();
        }

        private void GetPetData(pet pet)
        {
            //Holds the pet age.
            double age;

            //Get the pet's name.
            pet.Name = nameTextBox.Text;

            //Get the pet's type.
            pet.Type = typeTextBox.Text;

            //Get the pet's age.
            if (double.TryParse(ageTextBox.Text, out age))
            {
                pet.Age = age;
            }
            else
            {
                //Display an error message.
                MessageBox.Show("Invalid age. Please enter an amount in years.");
            }
        }

        private void addPetButton_Click(object sender, EventArgs e)
        {
            //Create a pet object.
            pet myPet = new pet();

            //Get the pet data.
            GetPetData(myPet);

            //Add the pet object to the list.
            petList.Add(myPet);

            //Add an entry to the list box.
            petListBox.Items.Add(myPet.Name + " " //+ myPet.Type
                                    );

            //Clear the textboxes.
            nameTextBox.Clear();
            typeTextBox.Clear();
            ageTextBox.Clear();

            //Reset the focus.
            nameTextBox.Focus();
        }

        private void petListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Get the index of the selected item.
            int index = petListBox.SelectedIndex;

            //Display the selected pet's name
            nameTextBox.Text = (petList[index].Name);

            //Display the selected pet's type.
            typeTextBox.Text = (petList[index].Type);

            //Display the selected pet's age.
            ageTextBox.Text=(petList[index].Age.ToString(""));
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
//End program.