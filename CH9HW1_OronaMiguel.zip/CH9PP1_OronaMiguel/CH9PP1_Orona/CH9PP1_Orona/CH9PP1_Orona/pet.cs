﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH9PP1_Orona
{
    class pet
    {
        //Fields.
        private string _name;   //The pet's name.
        private string _type;   //The pet's type.
        private double _age;    //The pet's age.

        //Constructor.
        public pet()
        {
            _name = "";
            _type = "";
            _age = 0;
        }

        //Name property.
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        //Type property.
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        //Age property.
        public double Age
        {
            get { return _age; }
            set { _age = value; }
        }
    }
}
//End class.