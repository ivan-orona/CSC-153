﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class car
    {
        //Fields
        double _year;
        double _mph;
        string _make;

        //Constructor
        public car(double year, string make)
        {
            _year = year;
            _make = make;
            _mph = 0;
        }

        public string make
        {
            get { return _make; }
            set { _make = value; }
        }

        public double year
        {
            get { return _year; }
            set { _year = value; }
        }

        public double mph
        {
            get { return _mph; }
            set { _mph = value; }
        }

        public void accelerateCarMph()
        {
            _mph = _mph + 5;
        }

        public void brakeCarMph() 
        {
            _mph = _mph - 5;
        }
    }
}
