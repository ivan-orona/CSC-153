﻿/**
* May 16, 2018
* CSC 153
* Miguel Ivan Orona
* This program will prompt the user to inour informatiion of a given pet
* and after processed the information will be stored in a listbox. When prompted,
* the program will retrieve the information and output it.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //The car class 
        private car car = new car(2012, "Road King");
        public Form1()
        {
            InitializeComponent();
        }

        //I accidently clicked on something and now if I delete this line the code 
        //breaks. Even if I just comment it out so I'm leaving it here.
        private void groupBox2_Enter(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
      
            carYearTextBox.Text = car.year.ToString();  //Converts the car year (double) to a string.
            carMakeTextBox.Text = car.make;             
            carSpeedTextBox.Text = car.mph.ToString();  //Converts the car speed (double) to a string.
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            car.accelerateCarMph(); //Calls the method to accelerate.
            carSpeedTextBox.Text = car.mph.ToString("0");
        }

        private void carBrakeButton_Click(object sender, EventArgs e)
        {
            //If the user enters zero (not a speed) they'll be prompted to re-enter.
            if (car.mph == 0)
                MessageBox.Show("Zero enter a valid MPH!");
            else
            {
                car.brakeCarMph();  //Calls the method to slow down.
                carSpeedTextBox.Text = car.mph.ToString("0");   
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}
//End program