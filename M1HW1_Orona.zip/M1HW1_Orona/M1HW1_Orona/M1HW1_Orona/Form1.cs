﻿//
//* February 7, 2018
//* CSC 153
//* Miguel Orona
//* This program will display three buttons with latin words prompting the 
//*user to input one. When the program processes the input, it will output
//*an English translation to the user until the program is exited.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW1_Orona
{
    public partial class latinTranslator : Form
    {
        public latinTranslator()
        {
            InitializeComponent();
        }

        private void sinisterButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "Left";
        }

        private void dexterButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "Right";
        }

        private void mediumButton_Click(object sender, EventArgs e)
        {
            translationLabel.Text = "Center";
        }
    }
}
//End Program