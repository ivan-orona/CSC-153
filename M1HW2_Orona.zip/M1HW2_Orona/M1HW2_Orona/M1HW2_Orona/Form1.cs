﻿//*February 7, 2018
//*CSC-153
//*Miguel Orona
//*This program will display five playing cards and prompt the user to choose one. 
//The program will process the input and output the name of the card. 
//Cards can continue to be chosen until the user exits the program.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            displayLabel.Text = "Eight of diamonds";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            displayLabel.Text = "Two of Clubs";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            displayLabel.Text = "King of Spades";
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            displayLabel.Text = "Ace of Spades";
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            displayLabel.Text = "Joker";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
//End Program